# Video.js Custom Skin Example

A Pen created on CodePen.io. Original URL: [https://codepen.io/heff/pen/wtrHL](https://codepen.io/heff/pen/wtrHL).

This is an example of how you can modify the CSS (or LESS in this case) of Video.js to create custom skins.